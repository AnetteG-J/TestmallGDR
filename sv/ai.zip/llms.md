# RegionStockholmGDR#0.1.0: Region Stockholms testmall implementationsguide FHIR(sv)

## Pages

* [Hem](index.md)
* [Nedladdningar](downloads.md)
* [Testning och validering](testing.md)
* [Förväntade svar](expected-responses.md)
* [CapabilityStatement](capabilitystatement.md)
* [Felhantering](error-handling.md)
* [Sammanfattning av artefakter](artifacts.md)
* [Användningsfall](use-cases.md)
* [Informationsunderlag](information-basis.md)
* [REST-interaktioner och sökparametrar](rest-interactions.md)
* [Versionshistorik](version-history.md)
* [Inledning](introduction.md)
* [Om](about.md)
* [Mappning till profiler](mappings.md)
* [Roller och ansvar](roles-and-responsibilities.md)
* [Säkerhet och behörighet](security.md)

## Resources

### Resource Profiles

* [Inera Patient](StructureDefinition-IneraPatient.md)
* [Stockholm Genomic Data File](StructureDefinition-stockholm-genomic-data-file.md)
* [Stockholm Genomic Patient](StructureDefinition-stockholm-genomic-patient.md)
* [Stockholm Genomic Related Person](StructureDefinition-stockholm-genomic-related-person.md)

### ImplementationGuides

* [Region Stockholms testmall implementationsguide FHIR](ImplementationGuide-RegionStockholmGDR.md)

### Examples

* [IneraPatientExample (Patient)](Patient-IneraPatientExample.md)
