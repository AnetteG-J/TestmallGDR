# Säkerhet och behörighet - Region Stockholms testmall implementationsguide FHIR v0.1.0

## Säkerhet och behörighet

**Beskriv de säkerhets- och behörighetsförutsättningar som gäller för att ansluta till och använda denna IG:s gränssnitt, t.ex. autentiseringsmetod, behörighetsmodell och eventuella krav på samtycke. Hänvisa till Ineras generella säkerhetskrav på [FHIR på Inera](https://fhir.inera.se/) där tillämpligt.**

